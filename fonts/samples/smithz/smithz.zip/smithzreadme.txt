S M I T H O L U T I O N - F O N T   V E R S I O N   0.96   B E T A 


What the Heck Is This?

Err, it was a single font, now it's whole font-family.

C'mon, you stupid xxxx, tell me some more!

Ok, it's a really small, but useable font. I came from the amiga and several other systems. I was really knee-deep in the real pixels. I know what pixels are, and I know what amount of information they can carry, if you let'em.
So I was always pissed about the way, user-Interfaces grew and grew (in pixel-sizes). No new functions, but everthing is getting bigger and bigger, your screen is filled with boring designed windows and oversized requesters'n'stuff.
I said to me, THAT IS CRAP ! I developed a smaller GUI, (which will be functional some day.. see my site, If you are interested, contact me!), and, of course, a smaller font (for the new GUI).
This is that font. The Smitholution Font. It saves space, looks good, and uses only pixels if it's absolutely necessary. If you disagree about that, do it better or die. ;-)

I have to add: Some people have weak eyes or fuzzy hongkong monitors (or both) and say: "Oh, that's too small... I can't read a thing!" ... Those kind of poeple can use BIG blurry anti-aliased fonts and waste their screen-space.



HOW TO USE

How Do I Install the Smitholution Font?

Just drag the suitcases you want to use onto your system folder icon. The Finder will ask you if you want to put it in your fonts folder, where it belongs. Click OK. That�s all.
Use the Appearance Control Panel (or similar in 7.x) to choose the font for List-Views etc.



SYSTEM REQUIREMENTS

Any Mac running System 7 or higher, with approx. 50 KB free on Hard Disk.
Maybe you can use this font with older systems, but I haven't tested that yet.
Anyone want to test it ?



FREQUENTLY ASKED QUESTIONS

 Q: Have you plans creating a vector-version of Smitholution Font ?
 A: Maybe... Contact me, if you know an easy way.
 
 Q: Will there be different versions of Smitholution Font ?
 A: Yes, there are various versions included in this release: 
    Roman, Bold, Capitals, Caps Bold, Fixed-Width, Ultra-Condensed 
    and Menu-Font plus Menu Condensed 12pt. etc. etc.

 Q: What is planned for the next releases ?
 A: Hmm, good question. I just want complete world domination by creating the
    best optimized bitmap-fonts for desktop-use ! I also want a new GUI-Style.

 Q: What about Mac OS X?
 A: I don't know much about adding new fonts AND I don't know about bitmap-fonts in OS X,
    I fear apple hasn't thought about it, I heard you can't disable those anti-aliasing.
    Anyway, OS X is far away from being a full featured system... Stay tuned.
    If you are a UNIX-Pro and can convert my fonts to UNIX'ish OSes (e.g. Linux, MacOS X,
    BSD, etc.) please contact me.

 Q: What about other Operating Systems ?
 A: I am looking forward to any conversion of my fonts. If you are interested in the fonts for Windows,
    Atari-OS (:-), Amiga-OS, BeOS or anything else, please contact me, maybe we can find a solution...

 Q: What about the numbers in the font-names ?
 A: These are the ID-Numbers of the fonts.

 Q: How to use the fonts ?
 A: Very important ! Use most of them at 9 pt, some are made in 12pt. (The Menu-Series)
    These fonts will only look good in their native size or double or triple...
    If you are unsure, look inside the font-suitcases and you'll see the native size... 9 or 12.. Have fun !



VERSION HISTORY

1997-1998
looking for a stupid editor for bitmap fonts... 
recognizing distructive thoughts for wasted pixels!

1999...
still searching.. building the font with photoshop'n'stuff

1999-07-01
first steps with res-edit (ignored the warning-req.)

1999-08-20
first alpha-version... (internal testing)

1999-08-31
first beta-release 0.6b

1999-09-02
next beta-release 0.7b (using NFNT-Editor 1.0a from Pandawave)

1999-11-9
minimal update 0.8b

1999-11-13
Update 0.9b

2001-04-12
Update 0.95b 

2001-08-02
Update 0.96b 



What�s New in Version 0.96b ?

� maybe some more bugs...
� Added Smithz Quad5, font based on 5x5 pixels square...
� Renamed Smithz Alternate to "classic" and Alt-Plus to "classic plus"
� Removed Menu-Cond2, that was a dead branch of Menu-Cond.
� Removed Smithz "no name", it was the same as Smithz Alternate... cleaned my family a bit


What�s New in Version 0.95b ?

� maybe some new bugs...
� Added Smithz AltPlus, "T" now 3pix, new small "r". 9pt.
� Added Smithz Quad7, tried to push all chars in rectangles + some dingbatz. 9pt.
� Added Smithz Quad9, tried to push all chars in rectangles, but Bold. 9pt.
� Added Smithz Caps Bold, a bold capitals font. 9pt.
� Added Smithz Menu Caps, a menu-variant with capitals. 12pt.
� Added Smithz Menu Cond, the condensed brother of MenuB. 12pt.
� Added Smithz MenuB, a bold font designed for Menus and anything else. 12pt.
� Added Smithz Mini, a small font, very similar to "mini7" or "silkscreen". 9pt.
� Added Smithz Ultra Mini, a more hardcore condensed font, THIS IS the maximum. 9pt.
� Added Smithz Ultra, a hardcore condensed font, THIS was the maximum. 9pt.
� Added Smithz Fixed, a fixed-width font, looks not as good as the normal Smithz, but sometimes you need those good old fixed width fonts. 9pt.
� Changed Smithz, sports new "w" and "m" plus minmal changes.


What�s New in Version 0.9b ?

� Added Smithz Caps, a font featuring capitals instead of "normal" lower case.
� Added Smithz Bold, a bold version of Smithz.


What�s New in Version 0.8b ?

� Big "T": now 1 pix less width -> No Space between T's and other chars...
� other minor changes that I've forgotten.


What�s New in Version 0.7b ?

� Special characters are mostly redesigned if possible
� Smitholution Font renamed to "Smithz"
� Font doesn't appear as a geneva anymore, It appears correctly as "Smithz"
� Line-Spacing was messed up in last version, fixed!




TECHNICAL SUPPORT

If you have questions, suggestions, words of appreciation or bug reports, you can contact me at the following address:

andi@smithz.org




KNOWN BUGS

Spacing when using these fonts for menus (e.g. with Appearance Hopper) is not correct, due to a bug in NFNT-Editor. Will be fixed very soon, I hope.

Note: A special bundle of Smithz is included with Appearance Hopper from Weedhopper Press. These fonts are fixed by hand, they work fine. Big thanks to Jeremiah Morris from Weedhopper Press.
 



UPDATE POLICY

New versions of the smithz font will be made available through my web pages:

http://www.smithz.org 

http://www.smitholution.com




SOME SHOUT-OUTS...

Feedback is welcome. 
Be kind. 
Search Bugs. 
Optimize your code. 
Don't believe the hype!
Believe in pixels!
Critizise everything.
Support Open-Source.

Don't trust Apple.

Nor trust Microsoft.

Trust yourself!




SPECIAL THANKS

TRX Trasholution, OH Studios, JoJo, Datastorm, HudeMob301, Alberto Ricci (for not updating Soundmaker), Mike Norris (great plugins and for helping Alberto Ricci NOT updating Soundmaker - just kidding, folks), Rabatz, Bill Woody from Panda Wave Software (for NFNT-Editor), Jeremiah Morris from Weedhopper Press (whpress.com)



MUSIC

CannibalCorpse, DocScott, NoUTurn, MosDef, Slayer, JMajik, Datastorm, BobMarley, Coltrane, JimiHendrix, Prince Farl, Mexican Narco-Music, Bulgarian Wedding-Tunes


DISCLAIMER

Smithz Font is copyright 1999-2001 by Smitholution Entertainment International. All rights reserved.

Please don't alter the font and upload it somewhere under its original name.
If you wan't to create a custom bitmap-font, I highly recommend NFNT-Edtitor from Pandawave. Or try Macromedia Fontographer which is overpowered, expensive and slow.

** USE AT YOUR OWN RISK **

THESE FONTS WERE EDITED USING ALPHA-SOFTWARE. (!)

THIS SOFTWARE IS PROVIDED "AS-IS". IT HAS NO WARRANTY OF ANY KIND. THE AUTHOR OF THIS SOFTWARE PACKAGE COULD NOT BE RESPONSIBLE OF THE USAGE MADE OF THIS SOFTWARE AND OF ANY DAMAGE THAT IT COULD CAUSE (IN ANY CASE). THE USE OF THIS SOFTWARE INCLUDE THE COMPLETE AGREEMENT OF THIS DISCLAIMER NOTICE.

BUT REMEMBER: I USE THESE FONTS TOO...

If you're interested in using the font for any project, feel free to contact me.



eof.
