The font Malij was a Macintosh downloaded off the Internet.  It seemed
to lack a Z and used a strange encoding, but I fiexed all that.  I do
not know the author.  If anyone knows the author, please let me know.
Since bitmapped fonts are not copyrightable in the U.S., I assume it's
OK to use, at least in the U.S.

Both the fonts here now use the mapping listed in keyboard.txt.

The font VP-Russian I also downloaded and modified.  It came with the
following information:

--------
About VP_Rus     If you use Macintosh as a remote terminal to mainframe
such as VAX and  want to be able to work with russian texts in KOI-8
coding, this package is for you.     At first you need to install
russian fonts into your communication program (VersaTerm PRO). The file
VP Russian Fonts - suitcase with appropriate 9-point fonts can be found
in the "Mac" folder. To install these fonts into VersaTerm PRO you
should use VersaTerm Font Installer (must be present in VersaTerm
distribution). You don't need to use the Font/DA Mover.    After
installation start VersaTerm PRO and make following settings. In
"Settings/Extras" select VT220/8-bit, and in "Emulations/Text
Attributes/Text Character Sets" select Text Font Size to be equal 9
points, assign "ASCII" for "g0" and "g1" sets and "Other" for "g2" and
"g3". Now you can view russian texts, but cannot enter russian
characters yet.     The most convenient way to solve this problem is to
install russian keyboard driver by Daniel Chirkov (included in his
package "koi8v2", which is available, for example, at ftp.kiae.su,
apple/cyrillic). But this way will not help you if your Mac runs under
System 6, or if the mainframe's operating system is not configured for
8-bit input. In this case you will have to use text editors with
built-in ability to switch keyboard.     Under UNIX and VAX VMS you may
use Emacs 19.15 or higher with macros for russian input created by
Alexander Kolbasov. These macros have been included into this package
(file "emacs-cyrillic" in the "VAX" folder).  Copy this file to
mainframe, read and cut off russian instructions in the beginning of
this file, and place it into subdirectory "lisp" in your home directory
as "cyrillic".     In addition to instructions included into this file,
it may be necessary to write full path ay use editor Red by Alex Rudnev
(available at ftp.kiae.su, unix/text/editors) as well.     If it is
impossible for you to install such text editors, you may use simplest
program "inprus.c" from the "VAX" folder. This program allows to type
texts in russian. Sorry, but editing capabilities are very poor:  it is
possible to edit only the current text string, before "Enter" key has
been pressed. Improve this program if you wish!     I hope that this
package will be useful for you.             Dmitri A. Martynoff
<x1059@kiae.su>       
--------

The font Hebrew.WRF is based on the BeerScheba Palm Pilot font by
Michael Neuhold. The original font came with the Gnu Public License.
However, since bitmapped fonts are not copyrightable in the U.S., the
Gnu Public License may not be valid.  If it is, you must abide by it--
see: http://www.gnu.org/copyleft/gpl.html

Source code for the Hebrew.WRF font can be obtained by renaming it to
hebrew.wzf, and running wzf2txt on it (get the Hi-Tech C SDK from
www.ozdev.com), and is also included in the Hi-Tech C SDK itself.

The HebrewSans.WRF font is based on a Hebrew block font for the Palm
Pilot that I downloaded from www.zalman.org

The characted mapping for the Hebrew fonts is:
a - alef
b - bet
g - gimel
d - dalet
h - he
w - vav
z - zayin
x - khet
j - tet
y - yod
k - kaf
l - lamed
m - mem
n - nun
o - samekh
e - `ayin
q - qof
r - resh
s - shin/sin
t - tav

